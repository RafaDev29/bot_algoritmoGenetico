# bot_algoritmoGenetico
Algoritmo para maximizar el mayor retorno para una combinación de recursos.
